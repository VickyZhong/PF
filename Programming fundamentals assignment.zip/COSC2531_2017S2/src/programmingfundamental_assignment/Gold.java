package programmingfundamental_assignment;

public class Gold extends GameItem {

	public Gold(char showLook) {
		super(showLook);
	}

	public char display() {
		char showLook = 'g';

		return super.display(showLook);
	}

}
