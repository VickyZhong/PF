package programmingfundamental_assignment;


public class World {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game myGame = new Game();
		myGame.runGame();
	}

}